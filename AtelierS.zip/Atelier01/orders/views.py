from django.contrib import messages
from django.shortcuts import redirect, render
from django.views import View

from cart.utils import get_user_or_session_cart

from .forms import OrderForm
from .models import OrderItem


class CreateOrderView(View):
    template_name = "orders/shipping.html"

    def get(self, request):
        cart = get_user_or_session_cart(request)
        if not cart.items.exists():
            messages.info(request, "Votre panier est vide.")
            return redirect("product_list")
        form = OrderForm()
        return render(request, self.template_name, {"form": form, "cart": cart})

    def post(self, request):
        cart = get_user_or_session_cart(request)
        if not cart.items.exists():
            messages.info(request, "Votre panier est vide.")
            return redirect("product_list")

        form = OrderForm(request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form, "cart": cart})

        order = form.save(commit=False)
        order.user = request.user if request.user.is_authenticated else None
        order.total_amount = cart.total_price
        order.save()

        for item in cart.items.select_related("product"):
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.price,
            )
            item.product.stock = max(item.product.stock - item.quantity, 0)
            item.product.save(update_fields=["stock"])

        cart.items.all().delete()
        return render(request, "orders/confirmation.html", {"order": order})
