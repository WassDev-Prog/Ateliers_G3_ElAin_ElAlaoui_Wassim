from django.test import TestCase
from django.urls import reverse

from cart.models import Cart
from products.models import Category, Product

from .models import Order


class OrderFlowTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Epices", slug="epices")
        self.product = Product.objects.create(
            category=category,
            name="Poivre",
            slug="poivre",
            description="Poivre noir",
            price=12,
            stock=10,
            is_active=True,
        )

    def test_shipping_redirects_if_cart_empty(self):
        response = self.client.get(reverse("create_order"))
        self.assertEqual(response.status_code, 302)

    def test_create_order_from_cart(self):
        self.client.post(reverse("add_to_cart", kwargs={"slug": self.product.slug}), {"quantity": 2})
        cart = Cart.objects.first()
        self.assertIsNotNone(cart)

        response = self.client.post(
            reverse("create_order"),
            {
                "full_name": "Client Test",
                "email": "client@test.com",
                "address": "Rue 10",
                "city": "Rabat",
                "postal_code": "10000",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Order.objects.count(), 1)
        order = Order.objects.first()
        self.assertEqual(order.items.count(), 1)
        self.assertEqual(cart.items.count(), 0)
