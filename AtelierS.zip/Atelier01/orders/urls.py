from django.urls import path

from .views import CreateOrderView

urlpatterns = [
    path("shipping/", CreateOrderView.as_view(), name="create_order"),
]
