# SimpliCulinary - Django Ateliers

Projet Django aligne sur les ateliers 1 a 5 (base, produits, utilisateurs, panier, commande).

## Demarrage rapide

```powershell
python -m venv venv
.\venv\Scripts\python -m pip install --upgrade pip
.\venv\Scripts\python -m pip install django pillow faker django-crispy-forms crispy-bootstrap5
.\venv\Scripts\python manage.py makemigrations
.\venv\Scripts\python manage.py migrate
.\venv\Scripts\python manage.py fake_data
.\venv\Scripts\python manage.py createsuperuser
.\venv\Scripts\python manage.py runserver
```

## MySQL (optionnel - Atelier 3)

1. Installer mysqlclient:

```powershell
.\venv\Scripts\python -m pip install mysqlclient
```

2. Creer la base `dbculinary` dans MySQL.
3. Copier `.env.example` vers `.env` puis adapter les variables.
4. Exporter les variables dans PowerShell puis lancer les migrations:

```powershell
$env:USE_MYSQL="1"
$env:MYSQL_DB="dbculinary"
$env:MYSQL_USER="root"
$env:MYSQL_PASSWORD="admin"
$env:MYSQL_HOST="localhost"
$env:MYSQL_PORT="3306"
.\venv\Scripts\python manage.py migrate
```

## Assets statiques (Atelier 4)

Remplacer les fichiers placeholders:

- `static/base/css/bootstrap.min.css`
- `static/base/js/bootstrap.bundle.min.js`
- `static/base/fontawesome/css/all.min.css`

Et copier les webfonts FontAwesome vers:

- `static/base/fontawesome/webfonts/`

## Mode demo enseignant (1 commande)

Script pret a l'emploi:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\demo_reset_and_run.ps1
```

Le script:

- recree/prepare l'environnement Python
- reinitialise `db.sqlite3`
- applique migrations
- injecte les fausses donnees
- cree un admin si inexistant
- lance `runserver`

Tu peux personnaliser les identifiants admin:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\demo_reset_and_run.ps1 `
  -AdminUsername "admin" `
  -AdminEmail "admin@example.com" `
  -AdminPassword "Admin12345!"
```

## Scripts utiles de presentation

Verifier rapidement les pages principales:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\demo_quick_check.ps1
```

Arreter le serveur Django du projet:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\stop_server.ps1
```
