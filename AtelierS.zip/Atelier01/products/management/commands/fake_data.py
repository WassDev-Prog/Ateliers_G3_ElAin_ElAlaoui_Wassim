from decimal import Decimal
from random import randint

from django.core.management.base import BaseCommand
from faker import Faker

from products.models import Category, Product


class Command(BaseCommand):
    help = "Generate fake categories and products."

    def handle(self, *args, **options):
        fake = Faker()
        categories = []
        for name in ["Fruits", "Legumes", "Epices", "Boissons"]:
            category, _ = Category.objects.get_or_create(
                slug=name.lower(), defaults={"name": name}
            )
            categories.append(category)

        for _ in range(20):
            name = fake.unique.word().capitalize()
            Product.objects.get_or_create(
                slug=f"{name.lower()}-{randint(100, 999)}",
                defaults={
                    "category": categories[randint(0, len(categories) - 1)],
                    "name": name,
                    "description": fake.sentence(nb_words=12),
                    "price": Decimal(str(randint(10, 200))),
                    "stock": randint(1, 50),
                    "is_active": True,
                },
            )

        self.stdout.write(self.style.SUCCESS("Fake data inserted successfully."))
