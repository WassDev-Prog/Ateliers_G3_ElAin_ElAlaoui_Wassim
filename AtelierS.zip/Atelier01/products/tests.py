from django.test import TestCase
from django.urls import reverse

from .models import Category, Product


class ProductViewsTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Fruits", slug="fruits")
        self.product = Product.objects.create(
            category=category,
            name="Orange",
            slug="orange",
            description="Fresh orange",
            price=20,
            stock=8,
            is_active=True,
        )

    def test_product_list_page_returns_200(self):
        response = self.client.get(reverse("product_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Orange")

    def test_product_detail_page_returns_200(self):
        response = self.client.get(reverse("product_detail", kwargs={"slug": self.product.slug}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.product.name)
