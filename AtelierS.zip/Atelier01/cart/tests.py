from django.test import TestCase
from django.urls import reverse

from products.models import Category, Product

from .models import Cart


class CartFlowTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Boissons", slug="boissons")
        self.product = Product.objects.create(
            category=category,
            name="Jus",
            slug="jus",
            description="Jus naturel",
            price=15,
            stock=4,
            is_active=True,
        )

    def test_add_to_cart_creates_item(self):
        response = self.client.post(
            reverse("add_to_cart", kwargs={"slug": self.product.slug}),
            {"quantity": 2},
        )
        self.assertEqual(response.status_code, 302)
        cart = Cart.objects.first()
        self.assertIsNotNone(cart)
        self.assertEqual(cart.items.count(), 1)
        self.assertEqual(cart.items.first().quantity, 2)

    def test_update_cart_item_quantity(self):
        self.client.post(reverse("add_to_cart", kwargs={"slug": self.product.slug}), {"quantity": 1})
        cart = Cart.objects.first()
        item = cart.items.first()

        response = self.client.post(
            reverse("cart_item_update", kwargs={"pk": item.pk}),
            {"quantity": 3},
        )
        self.assertEqual(response.status_code, 302)
        item.refresh_from_db()
        self.assertEqual(item.quantity, 3)
