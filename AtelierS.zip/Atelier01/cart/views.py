from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.views import View
from django.views.generic import DeleteView, DetailView

from products.models import Product

from .models import CartItem
from .utils import get_user_or_session_cart


class AddToCartView(View):
    def post(self, request, slug):
        product = get_object_or_404(Product, slug=slug, is_active=True)
        quantity = max(int(request.POST.get("quantity", 1)), 1)
        cart = get_user_or_session_cart(request)

        item, created = CartItem.objects.get_or_create(cart=cart, product=product)
        target_quantity = quantity if created else item.quantity + quantity

        if target_quantity > product.stock:
            messages.error(request, "Stock insuffisant pour ce produit.")
            return redirect("product_detail", slug=product.slug)

        item.quantity = target_quantity
        item.save()
        messages.success(request, "Produit ajoute au panier.")
        return redirect("cart_detail", pk=cart.pk)


class CartDetailsView(DetailView):
    template_name = "cart/detail_cart.html"
    context_object_name = "cart"

    def get_object(self, queryset=None):
        return get_user_or_session_cart(self.request)


class CartItemDeleteView(DeleteView):
    model = CartItem
    template_name = "cart/cartitem_delete.html"

    def get_success_url(self):
        cart = get_user_or_session_cart(self.request)
        return reverse("cart_detail", kwargs={"pk": cart.pk})


class CartItemUpdateView(View):
    def post(self, request, pk):
        cart = get_user_or_session_cart(request)
        item = get_object_or_404(CartItem, pk=pk, cart=cart)
        quantity = max(int(request.POST.get("quantity", 1)), 1)

        if quantity > item.product.stock:
            messages.error(request, "La quantite demandee depasse le stock.")
            return HttpResponseRedirect(reverse("cart_detail", kwargs={"pk": cart.pk}))

        item.quantity = quantity
        item.save()
        messages.success(request, "Quantite mise a jour.")
        return HttpResponseRedirect(reverse("cart_detail", kwargs={"pk": cart.pk}))
