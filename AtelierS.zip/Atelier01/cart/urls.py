from django.urls import path

from .views import AddToCartView, CartDetailsView, CartItemDeleteView, CartItemUpdateView

urlpatterns = [
    path("", CartDetailsView.as_view(), name="cart_detail"),
    path("<int:pk>/", CartDetailsView.as_view(), name="cart_detail"),
    path("add/<slug:slug>/", AddToCartView.as_view(), name="add_to_cart"),
    path("item/<int:pk>/delete/", CartItemDeleteView.as_view(), name="cart_item_delete"),
    path("item/<int:pk>/update/", CartItemUpdateView.as_view(), name="cart_item_update"),
]
