from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class UserAuthPagesTests(TestCase):
    def test_signup_page_returns_200(self):
        response = self.client.get(reverse("signup"))
        self.assertEqual(response.status_code, 200)

    def test_login_page_returns_200(self):
        response = self.client.get(reverse("login"))
        self.assertEqual(response.status_code, 200)

    def test_signup_creates_user(self):
        response = self.client.post(
            reverse("signup"),
            {
                "username": "newuser",
                "email": "newuser@example.com",
                "phone": "0600000000",
                "address": "Casa",
                "password1": "Securise12345!",
                "password2": "Securise12345!",
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(get_user_model().objects.filter(username="newuser").exists())
