param(
    [string]$AdminUsername = "admin",
    [string]$AdminEmail = "admin@example.com",
    [string]$AdminPassword = "Admin12345!"
)

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

if (-not (Test-Path ".\venv\Scripts\python.exe")) {
    Write-Host "Environnement virtuel introuvable. Creation de venv..."
    python -m venv venv
}

$python = ".\venv\Scripts\python.exe"

Write-Host "Installation des dependances..."
& $python -m pip install --upgrade pip
& $python -m pip install django pillow faker django-crispy-forms crispy-bootstrap5

if (Test-Path ".\db.sqlite3") {
    Write-Host "Suppression de la base SQLite existante..."
    Remove-Item ".\db.sqlite3" -Force
}

Write-Host "Migrations..."
& $python manage.py makemigrations
& $python manage.py migrate

Write-Host "Injection de donnees fake..."
& $python manage.py fake_data

Write-Host "Creation du superuser (si inexistant)..."
$env:DJANGO_SUPERUSER_USERNAME = $AdminUsername
$env:DJANGO_SUPERUSER_EMAIL = $AdminEmail
$env:DJANGO_SUPERUSER_PASSWORD = $AdminPassword

& $python manage.py shell -c "from django.contrib.auth import get_user_model; User=get_user_model(); import os; u=os.getenv('DJANGO_SUPERUSER_USERNAME'); e=os.getenv('DJANGO_SUPERUSER_EMAIL'); p=os.getenv('DJANGO_SUPERUSER_PASSWORD'); User.objects.filter(username=u).exists() or User.objects.create_superuser(username=u,email=e,password=p)"

Write-Host ""
Write-Host "Demo prete."
Write-Host "Admin username: $AdminUsername"
Write-Host "Admin email: $AdminEmail"
Write-Host "Admin password: $AdminPassword"
Write-Host "URL: http://127.0.0.1:8000/"
Write-Host ""
Write-Host "Lancement du serveur Django..."
& $python manage.py runserver
