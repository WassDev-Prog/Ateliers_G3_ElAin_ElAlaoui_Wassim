$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot

$pythonProcesses = Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq "python.exe" -and
    $_.CommandLine -match "manage.py runserver" -and
    $_.CommandLine -match [Regex]::Escape($projectRoot)
}

if (-not $pythonProcesses) {
    Write-Host "Aucun serveur Django a arreter pour ce projet."
    exit 0
}

foreach ($proc in $pythonProcesses) {
    try {
        Stop-Process -Id $proc.ProcessId -Force
        Write-Host "Serveur stoppe (PID: $($proc.ProcessId))."
    } catch {
        Write-Host "Impossible d'arreter PID $($proc.ProcessId): $($_.Exception.Message)"
    }
}
