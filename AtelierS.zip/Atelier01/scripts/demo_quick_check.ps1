param(
    [string]$BaseUrl = "http://127.0.0.1:8000"
)

$ErrorActionPreference = "Stop"

$pythonScript = @'
import sys
from urllib import request, error

base_url = sys.argv[1].rstrip("/")
checks = [
    {"Path": "/", "Allowed": [200]},
    {"Path": "/products/", "Allowed": [200]},
    {"Path": "/cart/", "Allowed": [200]},
    {"Path": "/users/login/", "Allowed": [200]},
    {"Path": "/users/signup/", "Allowed": [200]},
    {"Path": "/orders/shipping/", "Allowed": [200, 302]},
]

all_ok = True
for check in checks:
    url = base_url + check["Path"]
    allowed = set(check["Allowed"])
    status = None
    try:
        resp = request.urlopen(url, timeout=8)
        status = resp.getcode()
    except error.HTTPError as exc:
        status = exc.code
    except Exception:
        status = -1
    ok = status in allowed
    print(f"[{'OK' if ok else 'KO'}] {url} -> {status}")
    if not ok:
        all_ok = False

if all_ok:
    print("Verification rapide terminee: tout est OK.")
    sys.exit(0)

print("Verification rapide terminee: echec sur au moins une URL.")
sys.exit(1)
'@

$pythonExe = ".\venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    $pythonExe = "python"
}

$tempScript = Join-Path $env:TEMP "atelier01_quick_check.py"
Set-Content -Path $tempScript -Value $pythonScript -Encoding UTF8

try {
    & $pythonExe $tempScript $BaseUrl
    exit $LASTEXITCODE
} finally {
    if (Test-Path $tempScript) {
        Remove-Item $tempScript -Force
    }
}
